<?php
$name='THSarabunPSK';
$type='TTF';
$desc=array (
  'Ascent' => 850.0,
  'Descent' => -250.0,
  'CapHeight' => 476.0,
  'Flags' => 4,
  'FontBBox' => '[-427 -421 947 836]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 692.0,
);
$up=-35;
$ut=30;
$ttffile='C:\xampp\htdocs\project1\service\organizer\tfpdf/font/unifont/THSarabun.ttf';
$originalsize=99980;
$fontkey='dejavu';
?>